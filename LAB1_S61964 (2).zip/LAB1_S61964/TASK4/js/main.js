$(document).ready(function(){
    $('.header').height($(window).height());
   })
//    $(document).ready(function(){
//     $('.page-footer').width($(window).width());
//    })